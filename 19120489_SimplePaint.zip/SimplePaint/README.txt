Lưu Trường Dương 
MSSV 19120489 lớp 19_3
Giáo viên hướng dẫn : Thầy Trần Duy Quang

link demo: (bản mới nhất) 
https://www.youtube.com/watch?v=KE7KwULTAY0

link dự phòng: ( bản này không hiện chuột nên được quay lại)
https://www.youtube.com/watch?v=0N9C-4UAiYU

Cách chạy chương trình:
-chỉnh về phiên bản c++17
-chạy chế độ debug x86/ nếu để x64 sẽ không open và save as file được 
ấn crt + F5 để chạy chương trình bỏ qua debug

- ấn chuột phải để select sau đó chọn copy, kéo dữ chuột phải từ hình cũ 
sang vị trí mới cần copy hình qua rồi sau đó ấn paste.
tương tự vơi cut
- để delete cũng ấn chuột phải vào hình để select hình rồi ấn nút delete trên toolbar

Danh sách các tính năng:
-vẽ và đổi màu đường thẳng
-vẽ và đổi màu hình chữ nhật
-vẽ và đổi màu hình elipse
-Save as
-New
-Open
-Save
-undo
-Redow
-copy paste
-cut paste
-delete shape.

