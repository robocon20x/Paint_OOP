#include"Ellip.h"

Ellip::Ellip() {}

Ellip::Ellip(Point topLeft, Point rightBottom)
{
    _topLeft = topLeft;
    _rightBottom = rightBottom;
}

Ellip::Ellip(Point topLeft, Point rightBottom, DWORD color)
{
    _topLeft = topLeft;
    _rightBottom = rightBottom;
    _color = color;
}
Ellip::Ellip(int x, int y, int x1, int y1, DWORD color)
{
    _topLeft.setX(x);
    _topLeft.setY(y);
    _rightBottom.setX(x1);
    _rightBottom.setY(y1);
    _color = color;
}

Point Ellip::get_topLeft() { return _topLeft; }
Point Ellip::get_rightBottom() { return _rightBottom; }

void Ellip::setcolor(DWORD color) {
    _color = color;
}
DWORD Ellip::getcolor() { return _color; }

void Ellip::setpoint(int x, int y, int x1, int y1)
{
    _topLeft.setX(x);
    _topLeft.setY(y);
    _rightBottom.setX(x1);
    _rightBottom.setY(y1);
}
void Ellip::draw(HDC hdc) {

    Ellipse(hdc, _topLeft.x(), _topLeft.y(), _rightBottom.x(), _rightBottom.y());
}


string Ellip::type()
{
    return "Ellip";
}

string Ellip::toString()
{
    stringstream writer;

    writer << _topLeft.toString() << " " << _rightBottom.toString()
        << " " << _color;
    string result = writer.str();

    return result;
}
shared_ptr<isShape> Ellip::parse(string buffer) {
    vector<string> tokens = Tokenizor::split(buffer, " ");
    Point a = Point::parse(tokens[0]);
    Point b = Point::parse(tokens[1]);
    DWORD c = stoul(tokens[2]);

    auto result = make_shared<Ellip>(a, b, c);
    return result;
}

bool Ellip::isselected(int x, int y) {
    if (((_topLeft.x() < _rightBottom.x()) && (_topLeft.y() < _rightBottom.y())) || ((_topLeft.x() > _rightBottom.x()) && (_topLeft.y() > _rightBottom.y()))) {
        int max_x = max(_topLeft.x(), _rightBottom.x());
        int min_x = min(_topLeft.x(), _rightBottom.x());

        int max_y = max(_topLeft.y(), _rightBottom.y());
        int min_y = min(_topLeft.y(), _rightBottom.y());

        if (min_x <= x && x <= max_x)
            if (min_y <= y && y <= max_y) return true;
        return false;
    }
    if (((_topLeft.x() < _rightBottom.x()) && (_topLeft.y() < _rightBottom.y())) || ((_topLeft.x() > _rightBottom.x()) && (_topLeft.y() > _rightBottom.y()))) {
        int max_x = max(_topLeft.x(), _rightBottom.x());
        int min_x = min(_topLeft.x(), _rightBottom.x());

        int max_y = max(_topLeft.y(), _rightBottom.y());
        int min_y = min(_topLeft.y(), _rightBottom.y());

        if (min_x <= x && x <= max_x)
            if (min_y <= y && y <= max_y) return true;
        return false;
    }
    return false;
}

Ellip::~Ellip() {}