#pragma once
#include"isShape.h"
#include"Point.h"


class Ellip : public isShape
{
private:
    Point _topLeft;
    Point _rightBottom;
public:
    Ellip();

    Ellip(Point topLeft, Point rightBottom);
    Ellip(Point topLeft, Point rightBottom, DWORD color);
    Ellip(int x, int y, int x1, int y1,DWORD color);
    Point get_topLeft();
    Point get_rightBottom();
    void setcolor(DWORD color);
    DWORD getcolor();
    void setpoint(int x, int y, int x1, int y1);
    void draw(HDC hdc);
    string type();
    string toString();
    shared_ptr<isShape> parse(string buffer);
    bool isselected(int x, int y);
    ~Ellip();
};