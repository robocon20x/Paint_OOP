#pragma once
#include"Line.h"


Line::Line() {}

Line::Line(Point topLeft, Point rightBottom)
{
    _topLeft = topLeft;
    _rightBottom = rightBottom;
}
Line::Line(Point topLeft, Point rightBottom, DWORD color)
{
    _topLeft = topLeft;
    _rightBottom = rightBottom;
    _color = color;
}
Line::Line(int x, int y, int x1, int y1, DWORD color)
{
    _topLeft.setX(x);
    _topLeft.setY(y);
    _rightBottom.setX(x1);
    _rightBottom.setY(y1);
    _color = color;
}
Point Line::get_topLeft() { return _topLeft; }
Point Line::get_rightBottom() { return _rightBottom; }

void Line::setpoint(int x, int y, int x1, int y1)
{
    _topLeft.setX(x);
    _topLeft.setY(y);
    _rightBottom.setX(x1);
    _rightBottom.setY(y1);
}

void Line::setcolor(DWORD color) {
    _color = color;
}
DWORD Line::getcolor() { return _color; }

void Line::draw(HDC hdc) {

    MoveToEx(hdc, _topLeft.x(), _topLeft.y(), NULL);
    LineTo(hdc, _rightBottom.x(), _rightBottom.y());

}
string Line::type()
{
    return "Line";
}

string Line::toString()
{
    stringstream writer;

    writer << _topLeft.toString() << " " << _rightBottom.toString()
        << " " << _color;
    string result = writer.str();

    return result;
}

shared_ptr<isShape> Line::parse(string buffer) {
    vector<string> tokens = Tokenizor::split(buffer, " ");
    Point a = Point::parse(tokens[0]);
    Point b = Point::parse(tokens[1]);
    DWORD c = stoul(tokens[2]);

    auto result = make_shared<Line>(a, b, c);

    return result;
}
bool Line::isselected(int x, int y) {
    if (((_topLeft.x() < _rightBottom.x()) && (_topLeft.y() < _rightBottom.y())) || ((_topLeft.x() > _rightBottom.x()) && (_topLeft.y() > _rightBottom.y()))) {
        int max_x = max(_topLeft.x(), _rightBottom.x());
        int min_x = min(_topLeft.x(), _rightBottom.x());

        int max_y = max(_topLeft.y(), _rightBottom.y());
        int min_y = min(_topLeft.y(), _rightBottom.y());

        if (min_x <= x && x <= max_x)
            if (min_y <= y && y <= max_y) return true;
        return false;
    }
    if (((_topLeft.x() > _rightBottom.x()) && (_topLeft.y() < _rightBottom.y())) || ((_topLeft.x() < _rightBottom.x()) && (_topLeft.y() > _rightBottom.y()))) {
        int max_x = max(_topLeft.x(), _rightBottom.x());
        int min_x = min(_topLeft.x(), _rightBottom.x());

        int max_y = max(_topLeft.y(), _rightBottom.y());
        int min_y = min(_topLeft.y(), _rightBottom.y());

        if (min_x <= x && x <= max_x)
            if (min_y <= y && y <= max_y) return true;
        return false;
    }
    return false;
}

Line::~Line() {}