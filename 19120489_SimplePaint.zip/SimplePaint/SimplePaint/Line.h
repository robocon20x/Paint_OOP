#pragma once
#include"Point.h"
#include"isShape.h"
#include"framework.h"

using namespace std;

class Line : public isShape
{
private:
    Point _topLeft;
    Point _rightBottom;
public:
    Line();
    Line(Point topLeft, Point rightBottom);
    Line(Point topLeft, Point rightBottom, DWORD color);
    Line(int x, int y, int x1, int y1, DWORD color);

    Point get_topLeft();
    Point get_rightBottom();

    void setpoint(int x, int y, int x1, int y1);
    void setcolor(DWORD color);
    DWORD getcolor();
    void draw(HDC hdc);
    string type();
    string toString();
    shared_ptr<isShape> parse(string buffer);
    bool isselected(int x, int y);
    Line& operator =(const Line& B);
    ~Line();
};