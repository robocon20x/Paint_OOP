// class Point
#include"Point.h"



Point::Point() {}
Point::Point(int x, int y) {
    _x = x;
    _y = y;
}

int Point::x() { return _x; }
int Point::y() { return _y; }

void Point::setX(int x) { _x = x; }
void Point::setY(int y) { _y = y; }


string Point::toString() {
    stringstream writer;

    writer << _x << "," << _y;
    string result = writer.str();

    return result;
}

Point Point::parse(string buffer) {
    auto tokens = Tokenizor::split(buffer, ",");
    int a = stoi(tokens[0]);
    int b = stoi(tokens[1]);
    Point result(a, b);
    return result;
}
