#pragma once
#include<string>
#include<sstream>
#include"Tokenizer.h"
using namespace std;
class Point {
private:
    int _x;
    int _y;
public:
    Point();
    Point(int x, int y);
    int x();
    int y();
    void setX(int x);
    void setY(int y);
    string toString();
    static Point parse(string buffer);
};