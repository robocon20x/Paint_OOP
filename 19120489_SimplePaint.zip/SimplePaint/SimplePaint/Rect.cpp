#include"Rect.h"

Rect::Rect() {}
Rect::Rect(Point topLeft, Point rightBottom)
{
    _topLeft = topLeft;
    _rightBottom = rightBottom;
}

Rect::Rect(Point topLeft, Point rightBottom, DWORD color)
{
    _topLeft = topLeft;
    _rightBottom = rightBottom;
    _color = color;
}
Rect::Rect(int x, int y, int x1, int y1, DWORD color)
{
    _topLeft.setX(x);
    _topLeft.setY(y);
    _rightBottom.setX(x1);
    _rightBottom.setY(y1);
    _color = color;
}

Point Rect::get_topLeft() { return _topLeft; }
Point Rect::get_rightBottom() { return _rightBottom; }

void Rect::setcolor(DWORD color) {
    _color = color;
}
DWORD Rect::getcolor() { return _color; }

void Rect::setpoint(int x, int y, int x1, int y1)
{
    _topLeft.setX(x);
    _topLeft.setY(y);
    _rightBottom.setX(x1);
    _rightBottom.setY(y1);
}
void Rect::draw(HDC hdc) {

    Rectangle(hdc, _topLeft.x(), _topLeft.y(), _rightBottom.x(), _rightBottom.y());
}


string Rect::type()
{
    return "Rect";
}

string Rect::toString()
{
    stringstream writer;

    writer << _topLeft.toString() << " " << _rightBottom.toString()
        << " " << _color;
    string result = writer.str();

    return result;
}

shared_ptr<isShape> Rect::parse(string buffer) {
    vector<string> tokens = Tokenizor::split(buffer, " ");
    Point a = Point::parse(tokens[0]);
    Point b = Point::parse(tokens[1]);
    DWORD c = stoul(tokens[2]);

    auto result = make_shared<Rect>(a, b, c);
    return result;
}

bool Rect::isselected(int x, int y) {
    if (((_topLeft.x() < _rightBottom.x()) && (_topLeft.y() < _rightBottom.y())) || ((_topLeft.x() > _rightBottom.x()) && (_topLeft.y() > _rightBottom.y()))) {
        int max_x = max(_topLeft.x(), _rightBottom.x());
        int min_x = min(_topLeft.x(), _rightBottom.x());

        int max_y = max(_topLeft.y(), _rightBottom.y());
        int min_y = min(_topLeft.y(), _rightBottom.y());

        if (min_x <= x && x <= max_x)
            if (min_y <= y && y <= max_y) return true;
        return false;
    }
    if (((_topLeft.x() < _rightBottom.x()) && (_topLeft.y() < _rightBottom.y())) || ((_topLeft.x() > _rightBottom.x()) && (_topLeft.y() > _rightBottom.y()))) {
        int max_x = max(_topLeft.x(), _rightBottom.x());
        int min_x = min(_topLeft.x(), _rightBottom.x());

        int max_y = max(_topLeft.y(), _rightBottom.y());
        int min_y = min(_topLeft.y(), _rightBottom.y());

        if (min_x <= x && x <= max_x)
            if (min_y <= y && y <= min_y) return true;
        return false;
    }
    return false;
}


Rect::~Rect() {}