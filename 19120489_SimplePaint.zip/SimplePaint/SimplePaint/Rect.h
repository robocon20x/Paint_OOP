#pragma once
#include"isShape.h"
#include"Point.h"


class Rect : public isShape
{
private:
    Point _topLeft;
    Point _rightBottom;
public:
    Rect();
    Rect(Point topLeft, Point rightBottom);
    Rect(Point topLeft, Point rightBottom, DWORD color);
    Rect(int x, int y, int x1, int y1, DWORD color);
    Point get_topLeft();
    Point get_rightBottom();
    void setcolor(DWORD color);
    DWORD getcolor();
    void setpoint(int x, int y, int x1, int y1);
    void draw(HDC hdc);
    string type();
    string toString();

    shared_ptr<isShape> parse(string buffer);
    bool isselected(int x, int y);

    ~Rect();
};