#include"ShapeFactory.h"

ShapeFactory::ShapeFactory() {
    _prototypes.push_back(make_shared<Line>());
    _prototypes.push_back(make_shared<Rect>());
    _prototypes.push_back(make_shared<Ellip>());
}

ShapeFactory* ShapeFactory::instance() {
        if (_instance == NULL) {
            _instance = new ShapeFactory();
        }
        return _instance;
    }
    int ShapeFactory::typeCount() {
        return _prototypes.size();
    }

    shared_ptr<isShape> ShapeFactory::setpoint(string type,int x1, int y1, int x2, int y2, DWORD color) {
        if (type == "Line") {
            auto result = make_shared<Line>(x1, y1, x2, y2, color);
            return result;
        }
        if (type == "Rect") {
            auto result = make_shared<Rect>(x1, y1, x2, y2, color);
            return result;
        }
        if (type == "Ellip") {
            auto result = make_shared<Ellip>(x1, y1, x2, y2, color);
            return result;
        }
    }

    shared_ptr<isShape> ShapeFactory::parse(string type, string value) {
        shared_ptr<isShape> shape = NULL;
        for (int i = 0; i < _prototypes.size(); i++) {
            if (_prototypes[i]->type() == type) {
                shape = _prototypes[i]->parse(value);
                break;
            }
        }
        return shape;
    }