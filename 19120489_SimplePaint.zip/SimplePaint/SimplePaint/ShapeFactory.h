#include"isShape.h"
#include"Line.h"
#include"Ellip.h"
#include"Rect.h"

class ShapeFactory {
private:
    inline static ShapeFactory* _instance = NULL;
    vector<shared_ptr<isShape>> _prototypes;
    ShapeFactory();
public:
    static ShapeFactory* instance();
    int typeCount();
    shared_ptr<isShape> setpoint(string type,int x1, int y1, int x2, int y2, DWORD color);
    shared_ptr<isShape> parse(string type, string value);
};