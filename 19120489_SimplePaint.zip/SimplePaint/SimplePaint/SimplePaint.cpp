﻿#include"SimplePaint.h"

using namespace std;



// SimplePaint.cpp : Defines the entry point for the application.
//

void delete_data() {
    save_list.clear();
    redow.clear();
    shape_select = NULL;
    save_select = NULL;
}

void save_file(string filepath) {
    ofstream write;
    write.open(filepath);
    if (write.is_open())
    {
        write << save_list.size() << endl;

        for (int i = 0; i < save_list.size(); i++)
        {
            write << save_list[i]->type() << ": " << save_list[i]->toString() << endl;
        }
        cout << endl;

        write.close();
    }
    else {
        OutputDebugString(L"Can't open file txt to write");
    }

    write.close();
}

void open_file(string filepath) {
    ifstream read;
    read.open(filepath);
    if (read.is_open()) {

        int n;
        string str;
        read >> n;
        read.ignore();
        for (int i = 0; i < n; i++) {
            getline(read, str);
            vector<string> tokens = Tokenizor::split(str, ": ");
            save_list.push_back(ShapeFactory::instance()->parse(tokens[0], tokens[1]));
        }
        read.close();
    }
    else {
        OutputDebugString(L"Can't open file txt to read");
        read.close();
    }
}

// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Place code here.

    // Initialize global strings
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_SIMPLEPAINT, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Perform application initialization:
    if (!InitInstance(hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_SIMPLEPAINT));

    MSG msg;

    // Main message loop:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int)msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SIMPLEPAINT));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_SIMPLEPAINT);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    hInst = hInstance; // Store instance handle in our global variable

    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

    if (!hWnd)
    {
        return FALSE;
    }

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        HANDLE_MSG(hWnd, WM_CREATE, OnCreate);
        HANDLE_MSG(hWnd, WM_COMMAND, OnCommand);
        HANDLE_MSG(hWnd, WM_LBUTTONDOWN, OnLButtonDown);
        HANDLE_MSG(hWnd, WM_LBUTTONUP, OnLButtonUp);
        HANDLE_MSG(hWnd, WM_RBUTTONDOWN, OnRButtonDown);
        HANDLE_MSG(hWnd, WM_RBUTTONUP, OnRButtonUp);
        HANDLE_MSG(hWnd, WM_MOUSEMOVE, OnMouseMove);
        HANDLE_MSG(hWnd, WM_PAINT, OnPaint);
        HANDLE_MSG(hWnd, WM_DESTROY, OnDestroy);


    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

BOOL OnCreate(HWND hwnd, LPCREATESTRUCT lpCreateStruct)
{
    // Lấy font hệ thống
    LOGFONT lf;
    GetObject(GetStockObject(DEFAULT_GUI_FONT), sizeof(LOGFONT), &lf);
    HFONT hFont = CreateFont(lf.lfHeight, lf.lfWidth,
        lf.lfEscapement, lf.lfOrientation, lf.lfWeight,
        lf.lfItalic, lf.lfUnderline, lf.lfStrikeOut, lf.lfCharSet,
        lf.lfOutPrecision, lf.lfClipPrecision, lf.lfQuality,
        lf.lfPitchAndFamily, lf.lfFaceName);

    InitCommonControls();
    TBBUTTON tbButtons[] =
    {
        { STD_FILENEW,	ID_FILE_NEW, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { STD_FILEOPEN,	ID_FILE_OPEN, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { STD_FILESAVE,ID_FILE_SAVE, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }
    };
    HWND hToolBarWnd = CreateToolbarEx(hwnd,
        WS_CHILD | WS_VISIBLE | CCS_ADJUSTABLE | TBSTYLE_TOOLTIPS,
        ID_TOOLBAR, sizeof(tbButtons) / sizeof(TBBUTTON), HINST_COMMCTRL,
        0, tbButtons, sizeof(tbButtons) / sizeof(TBBUTTON),
        BUTTON_WIDTH, BUTTON_HEIGHT, IMAGE_WIDTH, IMAGE_HEIGHT,
        sizeof(TBBUTTON));

    TBBUTTON buttonsToAdd[] =
    {
        { 0, 0,	TBSTATE_ENABLED, TBSTYLE_SEP, 0, 0 }, // Nút phân cách
        { STD_CUT,	ID_EDIT_CUT, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { STD_COPY,	ID_EDIT_COPY, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { STD_PASTE, ID_EDIT_PASTE,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { STD_DELETE, ID_EDIT_DELETE, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { STD_UNDO, ID_EDIT_UNDO, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { STD_REDOW, ID_EDIT_REDOW, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }
    };
    SendMessage(hToolBarWnd, TB_ADDBUTTONS, (WPARAM)sizeof(buttonsToAdd) / sizeof(TBBUTTON),
        (LPARAM)(LPTBBUTTON)&buttonsToAdd);

    TBBUTTON userButtons[] =
    {
        { 0, 0,	TBSTATE_ENABLED, TBSTYLE_SEP, 0, 0 },
        { 0, ID_DRAW_ELLIPSE,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { 1, ID_DRAW_RECTANGLE,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 },
        { 2, ID_DRAW_LINE,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }

    };
    TBADDBITMAP	tbBitmap = { hInst, IDB_BITMAP1 };
    // Thêm danh sách ảnh vào toolbar
    int idx = SendMessage(hToolBarWnd, TB_ADDBITMAP, (WPARAM)sizeof(tbBitmap) / sizeof(TBADDBITMAP),
        (LPARAM)(LPTBADDBITMAP)&tbBitmap);
    // Xác định chỉ mục hình ảnh c ủa mỗi button từ ảnh bự liên hoàn nhiều tấm
    userButtons[1].iBitmap += idx;
    userButtons[2].iBitmap += idx;
    userButtons[3].iBitmap += idx;

    // Thêm nút bấm vào toolbar
    SendMessage(hToolBarWnd, TB_ADDBUTTONS, (WPARAM)sizeof(userButtons) / sizeof(TBBUTTON),
        (LPARAM)(LPTBBUTTON)&userButtons);


    return TRUE;
}

void OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    switch (id) {
    case ID_CHOOSE_COLOR: // chon mau de ve 
        ZeroMemory(&cc, sizeof(CHOOSECOLOR));
        cc.lStructSize = sizeof(CHOOSECOLOR);
        cc.hwndOwner = hwnd;
        cc.lpCustColors = (LPDWORD)acrCustClr;
        cc.rgbResult = rgbCurrent;
        cc.Flags = CC_FULLOPEN | CC_RGBINIT;
        if (ChooseColor(&cc))
        {
            hbrush = CreateSolidBrush(cc.rgbResult);
            rgbCurrent = cc.rgbResult;
        }
        break;
    case ID_CHOOSE_FONT: // chon font de vien text
        ZeroMemory(&cf, sizeof(CHOOSEFONT));
        cf.lStructSize = sizeof(CHOOSEFONT);
        cf.hwndOwner = hwnd;
        cf.lpLogFont = &lf;
        cf.Flags = CF_SCREENFONTS | CF_EFFECTS;

        if (ChooseFont(&cf) == TRUE)
        {
            hfont = CreateFontIndirect(cf.lpLogFont);
            hfontPrev = (HFONT)SelectObject(hdc, hfont);
            rgbCurrent = cf.rgbColors;
            rgbPrev = SetTextColor(hdc, rgbCurrent);
        }
        break;
    case ID_FILE_NEW: // thao tac voi nut new
        delete_data();
        InvalidateRect(hwnd, NULL, TRUE);
        break;
    case ID_FILE_SAVE:
        save_file(link); // save file dang mo, neu tung save file nay thi se save vao file text.txt mac dinh
        break;
    case ID_FILE_SAVEAS: // thao tac voi save as
        //Save Dialog
        OPENFILENAME saveFileDialog;
        char szSaveFileName[MAX_PATH];
        ZeroMemory(&saveFileDialog, sizeof(saveFileDialog));
        saveFileDialog.lStructSize = sizeof(saveFileDialog);
        saveFileDialog.hwndOwner = hwnd;
        saveFileDialog.lpstrFilter = (LPCWSTR)L"Text Files (*.txt)\0*txt\0All Files (*.*)\0*.*\0";
        saveFileDialog.lpstrFile = (LPWSTR)szSaveFileName;
        saveFileDialog.nMaxFile = MAX_PATH;
        saveFileDialog.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
        saveFileDialog.lpstrDefExt = (LPCWSTR)L"txt";

        if (GetSaveFileName(&saveFileDialog)) { // neu mo dialogbox thanh cong thi save file theo duong dan
            wstring ws((LPWSTR)szSaveFileName);
            string filepath(ws.begin(), ws.end());
            link = filepath;
            save_file(link);
        }
        break;
    case ID_FILE_OPEN: // thao tac voi nut open

        OPENFILENAME openFileDialog;
        char szFileName[MAX_PATH];
        ZeroMemory(&openFileDialog, sizeof(openFileDialog));
        openFileDialog.lStructSize = sizeof(openFileDialog);
        openFileDialog.hwndOwner = hwnd;
        openFileDialog.lpstrFilter = (LPCWSTR)L"Text Files (*.txt)\0*txt\0All Files (*.*)\0*.*\0";
        openFileDialog.lpstrFile = (LPWSTR)szFileName;
        openFileDialog.nMaxFile = MAX_PATH;
        openFileDialog.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
        openFileDialog.lpstrDefExt = (LPCWSTR)L"txt";

        if (GetOpenFileName(&openFileDialog)) {// neu mo dialogbox thanh cong thi open file theo duong dan

            wstring ws((LPWSTR)szFileName);
            string filepath(ws.begin(), ws.end());
            link = filepath;
            open_file(link);
            InvalidateRect(hwnd, NULL, TRUE);
        }

        break;
    case ID_DRAW_LINE: // ve duong thang 
        choosetype = "Line";
        break;
    case ID_DRAW_RECTANGLE: // ve hinh chu nhat
        choosetype = "Rect";
        break;
    case ID_DRAW_ELLIPSE: // ve hinh ellipse
        choosetype = "Ellip";
        break;
    case ID_EDIT_UNDO:// thao tac voi nut quay lai
        if (save_list.size() > 0) {
            redow.push_back(save_list[save_list.size() - 1]);
            save_list.pop_back();
            InvalidateRect(hwnd, NULL, TRUE);
            isundo = true;
        }
        break;
    case ID_EDIT_REDOW: // thao tac voi nut redow
        if (redow.size() > 0) {
            save_list.push_back(redow[redow.size() - 1]);
            redow.pop_back();
            InvalidateRect(hwnd, NULL, TRUE);
        }
        break;
    case ID_EDIT_DELETE: // thao tac xoa 
        if (selected && (save_list.size() > 0)) {
            save_list.erase(save_list.begin() + int_select);
            shape_select = NULL;
            selected = false;
            InvalidateRect(hwnd, NULL, TRUE);

        }
        break;
    case ID_EDIT_COPY:// thao tac copy
        if (iscut) {
            iscut = false;
        }
        iscopy = true;
        break;
    case ID_EDIT_CUT: // thao tac cut
        if (iscopy) {
            iscopy = false;
        }
        iscut = true;
        break;
    case ID_EDIT_PASTE: // thao tac paste
        if (iscopy || iscut) {
            Point select1 = save_select->get_topLeft();
            int x1 = select1.x();
            int y1 = select1.y();
            Point select2 = save_select->get_rightBottom();
            int x2 = select2.x();
            int y2 = select2.y();
            DWORD cl = save_select->getcolor();
            int a = select_tox - select_x;
            int b = select_toy - select_y;
            if (iscut) {
                save_list.erase(save_list.begin() + int_select);
                InvalidateRect(hwnd, NULL, TRUE);
            }
            save_list.push_back( ShapeFactory::instance()->setpoint(select_type, x1 + a, y1 + b, x2 + a, y2 + b, cl));
            InvalidateRect(hwnd, NULL, TRUE);
            shape_select = NULL;
            save_select = NULL;
            iscopy = false;
            iscut = false;
        }
        break;
    case IDM_EXIT:
        exit(0);
        break;
    }
}


void OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    hdc = BeginPaint(hwnd, &ps);
    HPEN hPen;
    for (int i = 0; i < save_list.size(); i++) {
        // Tạo pen với nét gạch chấm, độ dày là 3, màu của hình
        hPen = CreatePen(PS_DASHDOT, 3, save_list[i]->getcolor());
        SelectObject(hdc, hPen);
        save_list[i]->draw(hdc);
    }
    if (shape_select != NULL) {
        // Tạo pen với nét gạch chấm, độ dày là 3, màu của hình
        hPen = CreatePen(PS_DASHDOT, 3, shape_select->getcolor());
        SelectObject(hdc, hPen);
        shape_select->draw(hdc);
    }

    if (isDrawing) {
        hPen = CreatePen(PS_DASHDOT, 3, rgbCurrent);
        SelectObject(hdc, hPen);
        shared_ptr<isShape> temp12 = ShapeFactory::instance()->setpoint(choosetype, fromX, fromY, toX, toY, rgbCurrent);
        temp12->draw(hdc);
    }
    EndPaint(hwnd, &ps);
}


void OnLButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
{

    if (!isDrawing) {
        fromX = x;
        fromY = y;
        isDrawing = true;
        // xu ly undo voi redow
        isundo = false;
        redow.clear();
    }
}


void OnLButtonUp(HWND hwnd, int x, int y, UINT keyFlags)
{
    isDrawing = false;

    save_list.push_back(ShapeFactory::instance()->setpoint(choosetype, fromX, fromY, toX, toY, rgbCurrent));
    // Báo hiệu cần xóa đi toàn bộ màn hình & vẽ lại
    InvalidateRect(hwnd, NULL, TRUE);

}

void OnRButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
{
    select_x = x;
    select_y = y;
    isSelecting = true;
    for (int i = save_list.size() - 1; i >= 0; i--) {
        if (save_list[i]->isselected(x, y) == TRUE) {
            int_select = i;
            select_type = save_list[i]->type();
            selected = true;
            save_select = save_list[i];

            break;
        }
    }
}

void OnRButtonUp(HWND hwnd, int x, int y, UINT keyFlags)
{
    isSelecting = false;

    //Xu ly doi mau shape_select
    if (int_select != -1) {
        Point select1 = save_list[int_select]->get_topLeft();
        int x1 = select1.x();
        int y1 = select1.y();
        Point select2 = save_list[int_select]->get_rightBottom();
        int x2 = select2.x();
        int y2 = select2.y();
        DWORD cl = 6601476;
        shape_select = ShapeFactory::instance()->setpoint(select_type, x1, y1, x2, y2, cl);
        InvalidateRect(hwnd, NULL, TRUE);
    }
    //save_list.push_back(shape_select);
    InvalidateRect(hwnd, NULL, TRUE);
}

void OnMouseMove(HWND hwnd, int x, int y, UINT keyFlags)
{
    if (isDrawing) {
        toX = x;
        toY = y;
        // Báo hiệu cần xóa đi toàn bộ màn hình
        InvalidateRect(hwnd, NULL, TRUE);
    }
    if (isSelecting) {
        select_tox = x;
        select_toy = y;
    }
}

void OnDestroy(HWND hwnd)
{
    PostQuitMessage(0);
}



// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
