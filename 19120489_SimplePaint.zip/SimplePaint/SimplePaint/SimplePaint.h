﻿#pragma once


#include "resource.h"
#include "framework.h"
#include <windowsx.h>
#include <CommCtrl.h>
#pragma comment(lib, "Comctl32.lib")
#include <commdlg.h>
#include"Ellip.h"
#include"isShape.h"
#include"Line.h"
#include"Point.h"
#include"Rect.h"
#include"ShapeFactory.h"
#include"Tokenizer.h"
#include <sstream>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <memory> 
#include <iostream>
#include <time.h>


#define MAX_LOADSTRING 100
#define IMAGE_WIDTH     18
#define IMAGE_HEIGHT    18
#define BUTTON_WIDTH    0
#define BUTTON_HEIGHT   0

#define DEFAULT_COLOR 0x000000FF

// Global Variables:
HINSTANCE hInst;                                // current instance
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];            // the main window class name

int fromX;// diem den khi an chuot trai
int fromY;
int toX;// diem ngay khi vua an chuot trai
int toY;
bool isDrawing= false; // flag kiem tra co dang an chuot trai ko 
string default_link = "temp.txt";
string link = "temp.txt"; // filesave default 

bool selected= false; // kiem tra coi co dang select hinh nao khong 
bool isSelecting = false; // kiem tra chuot phai co an xuong khong 

DWORD select_color;// luu mau dang duoc chon 
int int_select = -1; // luu vi tri duoc chon
int select_x;// toa do voi thao tac chuot phai 
int select_y;
int select_tox;
int select_toy;
bool isundo = false; // flag kiem tra coi co dang undo khong 
bool iscopy = false; // flag kiem tra copy
bool iscut = false; // flag kiem tra cut


vector<shared_ptr<isShape>> save_list; // dung de luu nhung hinh da ve 

shared_ptr<isShape> shape_select; // dung de in dam hinh duoc chon 

shared_ptr<isShape> save_select; // luu hinh khi an save 

shared_ptr<isShape> select_inlist; // luu hinh duoc chon cua save_list

vector<shared_ptr<isShape>> redow;// luu nhung hinh da duoc undo

string select_type; // type dang duoc select

string choosetype = "Line";  // type dang chon de ve 


// bien toan cuc 
HDC hdc;

CHOOSECOLOR  cc; // Thông tin màu chọn
COLORREF  acrCustClr[16]; // Mảng custom color
DWORD  rgbCurrent = RGB(255, 0, 0); // Red
HBRUSH  hbrush; // Tạo ra brush từ màu đã chọn

CHOOSEFONT  cf; // thong tin font
LOGFONT  lf; // 
HFONT  hfont;
HFONT hfontPrev;
DWORD rgbPrev;

// ham anh xa WM
BOOL OnCreate(HWND hwnd, LPCREATESTRUCT lpCreateStruct);
void OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
void OnPaint(HWND hwnd);
void OnDestroy(HWND hwnd);
//mouse
void OnLButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags);
void OnLButtonUp(HWND hwnd, int x, int y, UINT keyFlags);
void OnRButtonUp(HWND hwnd, int x, int y, UINT keyFlags);
void OnRButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags);
void OnMouseMove(HWND hwnd, int x, int y, UINT keyFlags);

// cac ham thao tac
 // dung de xoa du lieu khi new hoac open
void delete_data();
// dung de save_file
void save_file(string filepath);
//dung de open file
void open_file(string filepath);

