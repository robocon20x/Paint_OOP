#include"Tokenizer.h"

vector<string> Tokenizor::split(string haystack, string needed = " ") {
    vector<string> tokens;
    int startPos = 0;
    size_t foundPos;

    while (true) {
        foundPos = haystack.find(needed, startPos);
        if (foundPos != string::npos) {
            string token = haystack.substr(startPos, foundPos - startPos);
            tokens.push_back(token);
            startPos = foundPos + needed.length();
        }
        else {
            string token = haystack.substr(startPos);
            tokens.push_back(token);
            break;
        }
    }
    return tokens;
}