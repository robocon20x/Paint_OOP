#pragma once
#include "framework.h"
#include <commdlg.h>
#include <sstream>
#include <vector>
#include <string>
#include <memory> 
#include"Point.h"



using namespace std;

class isShape
{
protected:
    DWORD _color;
public:
    isShape() {};
    virtual string toString() = 0;
    virtual string type() = 0;
    virtual Point get_topLeft() = 0;
    virtual Point get_rightBottom() = 0;
    virtual DWORD getcolor() = 0;
    virtual void setcolor(DWORD) = 0;
    virtual void draw(HDC hdc) = 0;
    virtual void setpoint(int x, int y, int x1, int y1) = 0;
    virtual bool isselected(int x, int y) = 0;
    virtual shared_ptr<isShape> parse(string buffer) = 0;
    virtual ~isShape() {};

};