//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SimplePaint.rc
//
#define IDC_MYICON                      2
#define IDD_SIMPLEPAINT_DIALOG          102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SIMPLEPAINT                 107
#define IDI_SMALL                       108
#define IDC_SIMPLEPAINT                 109
#define ID_FILE_NEW                     110
#define ID_FILE_OPEN                    111
#define ID_FILE_SAVE                    112
#define ID_TOOLBAR                      113
#define ID_EDIT_CUT                     114
#define ID_EDIT_COPY                    115
#define ID_EDIT_PASTE                   116
#define ID_EDIT_DELETE                  117
#define ID_DRAW_ELLIPSE                 118
#define ID_DRAW_RECTANGLE               119
#define ID_DRAW_LINE                    120
#define ID_DRAW_TEXT                    121
#define ID_EDIT_UNDO                    122
#define ID_EDIT_REDOW                   123
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define ID_CHOOSE_FONT                  32771
#define ID_CHOOSE_COLOR                 32772
#define ID_FILE_SAVEAS                  32773
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           124
#endif
#endif
